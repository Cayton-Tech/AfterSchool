// Possible solution for Question 2
package Question2Package;

public class CardHolder {

    // Code provided
    private String cardNumber;
    private String cellNumber;
    private int numVisits;
    private int loyaltyPoints;
    private char healthLevel;

    // Question 2.1.1
    public CardHolder(String cardNumber, String cellNumber, int loyaltyPoints) {  
        this.cardNumber = cardNumber;
        this.cellNumber = cellNumber;
        this.loyaltyPoints = loyaltyPoints; 
        this.numVisits = 0; 
        this.healthLevel = 'S';  
    }

    // Question 2.1.2
    public void setNumVisits(int numVisits) {
        this.numVisits = numVisits;
    }

    // Question 2.1.3
    public void increaseLoyaltyPoints(double total) { 
        loyaltyPoints = loyaltyPoints + (int) total / 4;  
    }

    // Question 2.1.4
    public void updateHealthLevel(double sumHealth, double sumTotal) {  
        double perc = sumHealth / sumTotal * 100;  
        // ranges 2
        healthLevel = 'S';  

        if (perc >= 10 && perc < 40) {
            healthLevel = 'G'; 
        }
        if (perc >= 40) {
            healthLevel = 'P';
        }
    }

    // Question 2.1.5
    public boolean isCorrect(int accessNum) {  //given
        String cNum = "";
        for (int cnt = 0; cnt < cellNumber.length(); cnt++) {
            if (cellNumber.charAt(cnt) != '0') 
            {
                cNum = cNum + cellNumber.charAt(cnt);  
            }
        }

        int sum = 0;  
        if (cNum.length() % 2 == 0) { 
            for (int cnt = 0; cnt < cNum.length(); cnt = cnt + 2) { 
                sum = sum + Integer.parseInt(cNum.substring(cnt, cnt + 2));  
            }
        } else {
            sum = Integer.parseInt(cNum.substring(0, 1)); 
            for (int cnt = 1; cnt < cNum.length(); cnt = cnt + 2) {  
                sum = sum + Integer.parseInt(cNum.substring(cnt, cnt + 2)); 
            }
        }

        if (sum==accessNum) {
            return true;  
        } else {
            return false;  
        }
    }

// Question 2.1.6
    public String identifyStarShopper() {
        String star = ""; 
        if ((loyaltyPoints > 2000 && numVisits > 10) || (healthLevel == 'P')) {  
            star = "STAR shopper";  
        }
        return star;  
    }

    // Code provided
    public String toString() {
        return cardNumber + "\nContact number: " + cellNumber + "\n\nUpdated number of loyalty points: " + loyaltyPoints + "\nNumber of visits: " + numVisits + "\nHealth evaluation status: " + healthLevel;
    }
}
