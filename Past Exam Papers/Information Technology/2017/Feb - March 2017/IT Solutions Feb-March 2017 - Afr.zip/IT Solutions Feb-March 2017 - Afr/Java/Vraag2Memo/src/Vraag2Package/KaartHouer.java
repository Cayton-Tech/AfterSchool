// Moontlike oplossing vir Vraag 2
package Vraag2Package;

public class KaartHouer {

    // Kode wat voorsien is
    private String kaartNommer;
    private String selNommer;
    private int aantbesoeke;
    private int lojaliteitsPunte;
    private char gesondVlak;

    // Vraag 2.1.1
    public KaartHouer(String kaartNommer, String selNommer, int lojaliteitsPunte) {  
        this.kaartNommer = kaartNommer;
        this.selNommer = selNommer;
        this.lojaliteitsPunte = lojaliteitsPunte; 
        this.aantbesoeke = 0; 
        this.gesondVlak = 'S';  
    }

    // Vraag 2.1.2
    public void setAantBesoeke(int aantbesoeke) {
        this.aantbesoeke = aantbesoeke;
    }

    // Vraag 2.1.3
    public void vermeerderLojaliteitsPunte(double totaal) { 
        lojaliteitsPunte = lojaliteitsPunte + (int) totaal / 4;  
    }

    // Vraag 2.1.4
    public void opdateerGesondVlak(double totaalGesond, double totaalBedrag) {  
        double persent = totaalGesond / totaalBedrag * 100;  
        gesondVlak = 'S';  

        if (persent >= 10 && persent < 40) {
            gesondVlak = 'G'; 
        }
        if (persent >= 40) {
            gesondVlak = 'P';
        }
    }

    // Vraag 2.1.5
    public boolean isReg(int toegangNom) {  //Gegee
        String cNommer = "";
        for (int tel = 0; tel < selNommer.length(); tel++) {
            if (selNommer.charAt(tel) != '0') 
            {
                cNommer = cNommer + selNommer.charAt(tel);  
            }
        }

        int som = 0;  
        if (cNommer.length() % 2 == 0) { 
            for (int tel = 0; tel < cNommer.length(); tel = tel + 2) { 
                som = som + Integer.parseInt(cNommer.substring(tel, tel + 2));  
            }
        } else {
            som = Integer.parseInt(cNommer.substring(0, 1)); 
            for (int tel = 1; tel < cNommer.length(); tel = tel + 2) {  
                som = som + Integer.parseInt(cNommer.substring(tel, tel + 2)); 
            }
        }

        if (som == toegangNom) {
            return true;  
        } else {
            return false;  
        }
    }

    // Vraag 2.1.6
    public String identifiseerSterKoper() {
        String ster = ""; 
        if ((lojaliteitsPunte > 2000 && aantbesoeke > 10) || (gesondVlak == 'P')) {  
            ster = "STER-koper";  
        }
        return ster;  
    }

    // Kode wat voorsien is
    public String toString() {
        return kaartNommer + "\nKontaknommer: " + selNommer + "\n\nOpgedateerde getal lojaliteitspunte: " + lojaliteitsPunte + "\nGetal besoeke: " + aantbesoeke + "\nGesondheidsevalueringstatus: " + gesondVlak;
    }
}
