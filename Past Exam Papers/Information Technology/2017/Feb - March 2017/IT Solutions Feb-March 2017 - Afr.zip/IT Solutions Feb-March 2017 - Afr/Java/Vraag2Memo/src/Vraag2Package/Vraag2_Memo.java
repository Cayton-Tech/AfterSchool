/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Vraag2Package;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Administrator
 */
public class Vraag2_Memo extends javax.swing.JFrame {

    KaartHouer objKaartHouer = null;  // Kode wat voorsien is

    public Vraag2_Memo() {
        initComponents();
        setLocationRelativeTo(this);
        btnVraag222.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        pnlVraag2_1 = new javax.swing.JPanel();
        btnVraag221 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        lblLojaliteitsPunte = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cmbKaartNommers = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblSelNommer = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txfKode = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        pnlVraag2_2 = new javax.swing.JPanel();
        btnVraag222 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txaAfvoer = new javax.swing.JTextArea();

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlVraag2_1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Vraag 2_2_1", 0, 0, new java.awt.Font("Arial", 0, 12))); // NOI18N

        btnVraag221.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnVraag221.setText("2.2.1 - Kontroleer toegangskode");
        btnVraag221.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVraag221ActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblLojaliteitsPunte.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblLojaliteitsPunte.setText("2130");

        jLabel6.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel6.setText("Lojaliteitspunte");
        jLabel6.setToolTipText("");

        cmbKaartNommers.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        cmbKaartNommers.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "B921-3$-AF", "B870-4%-LI", "P730-7*-AF", "B810-2#-AF" }));
        cmbKaartNommers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbKaartNommersActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel1.setText("Lojaliteitskaart se nommer");

        jLabel2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel2.setText("Selfoonnommer");

        lblSelNommer.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblSelNommer.setText("0812345678");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 92, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                                .addComponent(cmbKaartNommers, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(56, 56, 56)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblLojaliteitsPunte, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSelNommer, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cmbKaartNommers, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(82, 82, 82)
                .addComponent(lblSelNommer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(lblLojaliteitsPunte, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(10, 10, 10))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel3.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel3.setText("Toegangskode");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(93, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txfKode, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(80, 80, 80))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txfKode, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout pnlVraag2_1Layout = new javax.swing.GroupLayout(pnlVraag2_1);
        pnlVraag2_1.setLayout(pnlVraag2_1Layout);
        pnlVraag2_1Layout.setHorizontalGroup(
            pnlVraag2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVraag2_1Layout.createSequentialGroup()
                .addGroup(pnlVraag2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlVraag2_1Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(pnlVraag2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(pnlVraag2_1Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(btnVraag221, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 22, Short.MAX_VALUE))
        );
        pnlVraag2_1Layout.setVerticalGroup(
            pnlVraag2_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVraag2_1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnVraag221, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Lojaliteitstoekenningstelsel");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 56, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlVraag2_2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Vraag 2_2_2", 0, 0, new java.awt.Font("Arial", 0, 12))); // NOI18N

        btnVraag222.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnVraag222.setText("2.2.2 - Vertoon kaarthouer se besonderhede");
        btnVraag222.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVraag222ActionPerformed(evt);
            }
        });

        txaAfvoer.setColumns(20);
        txaAfvoer.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txaAfvoer.setRows(5);
        jScrollPane1.setViewportView(txaAfvoer);

        javax.swing.GroupLayout pnlVraag2_2Layout = new javax.swing.GroupLayout(pnlVraag2_2);
        pnlVraag2_2.setLayout(pnlVraag2_2Layout);
        pnlVraag2_2Layout.setHorizontalGroup(
            pnlVraag2_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVraag2_2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlVraag2_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlVraag2_2Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(btnVraag222, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlVraag2_2Layout.setVerticalGroup(
            pnlVraag2_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlVraag2_2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnVraag222, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(pnlVraag2_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlVraag2_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pnlVraag2_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlVraag2_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVraag221ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVraag221ActionPerformed
        String kaartNom = "" + cmbKaartNommers.getSelectedItem();
        String selNom = lblSelNommer.getText();
        String toegangNommer  = txfKode.getText();
        int toegangNom = 0;
        try {
            toegangNom = Integer.parseInt(toegangNommer);
        } catch (NumberFormatException e) {    
        }

        int huidigePunte = Integer.parseInt(lblLojaliteitsPunte.getText());
        objKaartHouer = new KaartHouer(kaartNom, selNom, huidigePunte);
        if (objKaartHouer.isReg(toegangNom)) {
            JOptionPane.showMessageDialog(rootPane, "Die toegangskode is reg.");
            try {
                Scanner scLeer = new Scanner(new FileReader("DataJanuarie2017.txt"));
                double totaalBedrag = 0;
                double totaalGesond = 0;
                int teller = 0;
                while (scLeer.hasNext()) {
                    String kaart = scLeer.nextLine();
                    double bedrag = Double.parseDouble(scLeer.nextLine());
                    double gesondBedrag = Double.parseDouble(scLeer.nextLine());
                    if (kaart.equalsIgnoreCase(kaartNom)) {
                        totaalBedrag = totaalBedrag + bedrag;
                        totaalGesond = totaalGesond + gesondBedrag;
                        teller++;
                    }
                }
                objKaartHouer.setAantBesoeke(teller);
                objKaartHouer.vermeerderLojaliteitsPunte(totaalBedrag);
                objKaartHouer.opdateerGesondVlak(totaalGesond, totaalBedrag);
            } catch (FileNotFoundException e) {
                JOptionPane.showMessageDialog(rootPane, e);
            }
            btnVraag222.setEnabled(true);
        } else {
            JOptionPane.showMessageDialog(rootPane, "Verkeerde toegangskode.");
            txfKode.setText("");
        }
    }//GEN-LAST:event_btnVraag221ActionPerformed

    private void btnVraag222ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVraag222ActionPerformed
        txaAfvoer.setText(objKaartHouer.toString());
        txaAfvoer.append("\n" + objKaartHouer.identifiseerSterKoper());
    }//GEN-LAST:event_btnVraag222ActionPerformed

    // Kode wat voorsien is
    private void cmbKaartNommersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbKaartNommersActionPerformed
        opdateerVanPunte();
    }//GEN-LAST:event_cmbKaartNommersActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;


                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vraag2_Memo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vraag2_Memo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vraag2_Memo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vraag2_Memo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vraag2_Memo().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVraag221;
    private javax.swing.JButton btnVraag222;
    private javax.swing.JComboBox cmbKaartNommers;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblLojaliteitsPunte;
    private javax.swing.JLabel lblSelNommer;
    private javax.swing.JPanel pnlVraag2_1;
    private javax.swing.JPanel pnlVraag2_2;
    private javax.swing.JTextArea txaAfvoer;
    private javax.swing.JTextField txfKode;
    // End of variables declaration//GEN-END:variables
    // Given code

    public void opdateerVanPunte() {
        if (cmbKaartNommers.getSelectedIndex() == 0) {
            lblLojaliteitsPunte.setText("2130");
            lblSelNommer.setText("0812345678");
        }
        if (cmbKaartNommers.getSelectedIndex() == 1) {
            lblLojaliteitsPunte.setText("5723");
            lblSelNommer.setText("0822001100");
        }
        if (cmbKaartNommers.getSelectedIndex() == 2) {
            lblLojaliteitsPunte.setText("12908");
            lblSelNommer.setText("0740998877");
        }
        if (cmbKaartNommers.getSelectedIndex() == 3) {
            lblLojaliteitsPunte.setText("500");
            lblSelNommer.setText("0720951083");
        }
        txaAfvoer.setText("");
        txfKode.setText("");
        btnVraag222.setEnabled(false);
    }
}
